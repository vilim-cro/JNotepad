package hr.fer.oprpp1.jnotepadpp.local;

public interface ILocalizationListener {
    void localizationChanged();
}
